document.addEventListener('DOMContentLoaded', () => {
  // Переменные для хранения данных о курсах валют
  let currentRates = {};
  let historicalRates = {};
  let baseCurrency = 'RUB';
  
  // Массив финансовых цитат
  const financialQuotes = [
    { text: "Деньги — это шестое чувство, без которого нельзя в полной мере насладиться остальными пятью.", author: "Сомерсет Моэм" },
    { text: "Инвестиции в знания всегда дают наибольшую прибыль.", author: "Бенджамин Франклин" },
    { text: "Богатство — это не количество денег, а отношение расходов к доходам.", author: "Чарльз Диккенс" },
    { text: "Скупой платит дважды.", author: "Народная мудрость" },
    { text: "Деньги должны быть слугами, а не повелителями.", author: "Фрэнсис Бэкон" },
    { text: "Путь к богатству зависит главным образом от двух слов: трудолюбие и бережливость.", author: "Бенджамин Франклин" },
    { text: "Пока вы не научитесь управлять своими деньгами, вы никогда не сможете заработать их.", author: "Роберт Кийосаки" },
    { text: "Никогда не занимайте деньги у человека, который подчеркивает важность их своевременного возврата.", author: "Уильям Шекспир" },
    { text: "Покупайте, когда на улицах льётся кровь, даже если кровь — ваша.", author: "Уоррен Баффет" },
    { text: "Цена — это то, что вы платите. Ценность — это то, что вы получаете.", author: "Уоррен Баффет" },
    { text: "Богатство не определяется суммой денег, но образом жизни, который мы ведем.", author: "Мухаммед" },
    { text: "Когда деньги говорят, правда молчит.", author: "Китайская пословица" },
    { text: "Доллар сегодня стоит больше, чем доллар завтра.", author: "Принцип временной стоимости денег" },
    { text: "Если вы думаете, что образование дорого, то попробуйте невежество.", author: "Роберт Орбен" },
    { text: "Финансовая свобода — это когда пассивный доход превышает ваши расходы.", author: "Тони Роббинс" }
  ];
  
  // Функция для случайной финансовой цитаты
  function displayRandomQuote() {
    const quoteIndex = Math.floor(Math.random() * financialQuotes.length);
    const quote = financialQuotes[quoteIndex];
    
    document.getElementById('quote-content').textContent = quote.text;
    document.getElementById('quote-author').textContent = `— ${quote.author}`;
  }
  
  // Вызываем функцию при загрузке страницы
  displayRandomQuote();

  // Переключение темы
  const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');

  function switchTheme(e) {
    if (e.target.checked) {
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.setAttribute('data-theme', 'light');
      localStorage.setItem('theme', 'light');
    }
  }

  toggleSwitch.addEventListener('change', switchTheme, false);

  // Проверка сохраненной темы
  const currentTheme = localStorage.getItem('theme') || 'light';
  if (currentTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
    toggleSwitch.checked = true;
  }

  // Обновление даты и времени
  function updateDateTime() {
    const now = new Date();
    const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };

    document.querySelector('.date').textContent = now.toLocaleDateString('ru-RU', dateOptions);
    document.querySelector('.time').textContent = now.toLocaleTimeString('ru-RU', timeOptions);

    document.getElementById('last-update').textContent = now.toLocaleTimeString('ru-RU', timeOptions);
  }

  // Обновление каждую секунду
  setInterval(updateDateTime, 1000);
  updateDateTime();

  // Функция для получения курсов валют
  async function fetchExchangeRates() {
    try {
      // В реальном проекте здесь был бы запрос к API
      // Для демонстрации используем фиктивные данные

      // Симуляция задержки сети
      await new Promise(resolve => setTimeout(resolve, 800));

      // Генерация случайных курсов валют для демонстрации
      const usdRate = 90 + Math.random() * 5;

      currentRates = {
        USD: usdRate,
        EUR: usdRate * (1 + (Math.random() * 0.2 - 0.1)),
        CNY: usdRate / (6.5 + Math.random()),
        KZT: usdRate / (0.0021 + Math.random() * 0.0005),
      };

      // Обновление исторических данных
      if (!historicalRates.USD) {
        historicalRates = generateHistoricalRates(currentRates, 30);
      }

      updateRatesDisplay();
      updateExchangeStatus();
      generateForecasts();
      updateChart('USD', 'month'); // Update chart on initial load

      return true;
    } catch (error) {
      console.error('Ошибка при получении курсов валют:', error);
      return false;
    }
  }

  // Генерация исторических данных для демонстрации
  function generateHistoricalRates(baseRates, days) {
    const historical = {
      USD: [],
      EUR: [],
      CNY: [],
      KZT: [],
      dates: []
    };

    const today = new Date();

    for (let i = days; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      historical.dates.push(date.toISOString().split('T')[0]);

      // Добавление случайных колебаний для курсов
      const dayVariation = Math.random() * 0.04 - 0.02; // ±2%

      historical.USD.push(baseRates.USD * (1 + dayVariation + (i / days) * 0.05));
      historical.EUR.push(baseRates.EUR * (1 + dayVariation - (i / days) * 0.03));
      historical.CNY.push(baseRates.CNY * (1 + dayVariation + (i / days) * 0.02));
      historical.KZT.push(baseRates.KZT * (1 + dayVariation - (i / days) * 0.04));
    }

    return historical;
  }

  // Обновление отображения курсов валют
  function updateRatesDisplay() {
    for (const [currency, rate] of Object.entries(currentRates)) {
      const element = document.getElementById(currency.toLowerCase());
      if (element) {
        // Форматирование числа с разделителем тысяч и двумя знаками после запятой
        const formattedRate = rate.toLocaleString('ru-RU', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        element.querySelector('.currency-value').textContent = formattedRate;
      }
    }
  }

  // Обновление статуса курса (выгодно/невыгодно)
  function updateExchangeStatus() {
    // Расчет средних значений за последние 7 дней
    const lastWeekAverages = {};
    const currencies = ['USD', 'EUR', 'CNY', 'KZT'];

    currencies.forEach(currency => {
      const ratesArray = historicalRates[currency];
      const lastWeekRates = ratesArray.slice(-8, -1); // последние 7 дней без сегодня
      const average = lastWeekRates.reduce((sum, rate) => sum + rate, 0) / lastWeekRates.length;
      lastWeekAverages[currency] = average;
    });

    // Обновление статуса для каждой валюты
    currencies.forEach(currency => {
      const element = document.getElementById(currency.toLowerCase());
      if (!element) return;

      const currentRate = currentRates[currency];
      const avgRate = lastWeekAverages[currency];
      const statusElement = element.querySelector('.currency-status');

      // Процентное отклонение от среднего
      const deviation = ((currentRate - avgRate) / avgRate) * 100;

      // Определение статуса на основе отклонения
      let statusClass, statusText;

      if (deviation <= -2) {
        statusClass = 'status-excellent';
        statusText = 'Отлично';
      } else if (deviation >= 2) {
        statusClass = 'status-bad';
        statusText = 'Плохо';
      } else {
        statusClass = 'status-good';
        statusText = 'Хорошо';
      }

      statusElement.className = 'currency-status ' + statusClass;
      statusElement.textContent = statusText;
    });
  }

  // Генерация прогнозов на основе исторических данных
  function generateForecasts() {
    // Простая линейная регрессия для прогнозирования
    const getLinearTrend = (data, days) => {
      const n = data.length;
      let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;

      for (let i = 0; i < n; i++) {
        sumX += i;
        sumY += data[i];
        sumXY += i * data[i];
        sumXX += i * i;
      }

      const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
      const intercept = (sumY - slope * sumX) / n;

      // Прогноз на следующие дни
      const forecast = [];
      for (let i = 1; i <= days; i++) {
        forecast.push(intercept + slope * (n + i - 1));
      }

      return forecast;
    };

    // Получаем прогнозы для каждой валюты
    const forecastDays = 30; // на месяц вперед
    const forecasts = {};

    ['USD', 'EUR', 'CNY', 'KZT'].forEach(currency => {
      forecasts[currency] = getLinearTrend(historicalRates[currency], forecastDays);
    });

    // Создаем массив дат для прогноза
    const forecastDates = [];
    const today = new Date();

    for (let i = 1; i <= forecastDays; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      forecastDates.push(date.toISOString().split('T')[0]);
    }

    // Сохраняем прогнозы
    const forecastData = {
      dates: forecastDates,
      rates: forecasts
    };

    // Отображаем прогноз на завтра по умолчанию
    displayForecast(forecastData, 'tomorrow');

    // Добавляем обработчики для вкладок прогноза
    document.querySelectorAll('.forecast-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.forecast-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        displayForecast(forecastData, tab.dataset.period);
      });
    });
  }

  // Отображение прогноза в зависимости от выбранного периода
  function displayForecast(forecastData, period) {
    const tableBody = document.getElementById('forecast-table-body');
    tableBody.innerHTML = '';

    let days;
    switch (period) {
      case 'tomorrow':
        days = 1;
        break;
      case 'week':
        days = 7;
        break;
      case 'month':
        days = 30;
        break;
      default:
        days = 1;
    }

    for (let i = 0; i < days; i++) {
      const row = document.createElement('tr');

      // Форматирование даты
      const dateParts = forecastData.dates[i].split('-');
      const formattedDate = `${dateParts[2]}.${dateParts[1]}.${dateParts[0]}`;

      // Добавление ячейки с датой
      const dateCell = document.createElement('td');
      dateCell.textContent = formattedDate;
      row.appendChild(dateCell);

      // Добавление ячеек с прогнозами для каждой валюты
      ['USD', 'EUR', 'CNY', 'KZT'].forEach(currency => {
        const cell = document.createElement('td');
        const rate = forecastData.rates[currency][i];
        cell.textContent = rate.toLocaleString('ru-RU', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        row.appendChild(cell);
      });

      tableBody.appendChild(row);
    }
  }

  // Функционал калькулятора валют
  const amountInput = document.getElementById('amount');
  const resultInput = document.getElementById('result');
  const fromCurrencySelect = document.getElementById('from-currency');
  const toCurrencySelect = document.getElementById('to-currency');
  const calculateBtn = document.getElementById('calculate-btn');
  const exchangeRateSpan = document.getElementById('exchange-rate');
  const swapBtn = document.getElementById('swap-currencies');

  // Функция расчета обмена валют
  function calculateExchange() {
    const amount = parseFloat(amountInput.value);
    if (isNaN(amount) || amount <= 0) {
      alert('Пожалуйста, введите корректную сумму');
      return;
    }

    const fromCurrency = fromCurrencySelect.value;
    const toCurrency = toCurrencySelect.value;

    // Получение курсов для расчета
    let rate;

    if (fromCurrency === 'RUB' && toCurrency === 'RUB') {
      rate = 1;
    } else if (fromCurrency === 'RUB') {
      rate = 1 / currentRates[toCurrency];
    } else if (toCurrency === 'RUB') {
      rate = currentRates[fromCurrency];
    } else {
      // Конвертация через рубль
      rate = currentRates[fromCurrency] / currentRates[toCurrency];
    }

    // Комиссия (0.5%)
    const commission = 0.005;
    document.getElementById('commission').textContent = '0.5%';

    // Расчет и отображение результата
    const result = amount * rate * (1 - commission);
    resultInput.value = result.toLocaleString('ru-RU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).replace(/\s/g, '');

    // Отображение курса обмена
    exchangeRateSpan.textContent = rate.toLocaleString('ru-RU', {
      minimumFractionDigits: 4,
      maximumFractionDigits: 4
    });
  }

  // Обмен валют местами
  function swapCurrencies() {
    const tempCurrency = fromCurrencySelect.value;
    fromCurrencySelect.value = toCurrencySelect.value;
    toCurrencySelect.value = tempCurrency;

    if (amountInput.value && resultInput.value) {
      const tempAmount = amountInput.value;
      amountInput.value = resultInput.value;
      resultInput.value = tempAmount;
    }
  }

  // Обработчики событий
  calculateBtn.addEventListener('click', calculateExchange);
  swapBtn.addEventListener('click', swapCurrencies);

  // Функция для загрузки новостей
  function loadFinancialNews() {
    // Имитация новостей (в реальном проекте здесь был бы API запрос)
    const mockNews = [
      {
        title: "Центральный банк понизил ключевую ставку",
        date: "25 апреля 2023",
        snippet: "Центральный банк принял решение о снижении ключевой ставки на 0,25 процентного пункта на фоне замедления инфляции.",
        imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
      },
      {
        title: "Мировые рынки реагируют на нестабильность в экономике",
        date: "23 апреля 2023",
        snippet: "Основные фондовые индексы демонстрируют смешанную динамику на фоне опасений рецессии и роста инфляции в развитых странах.",
        imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
      },
      {
        title: "Новые санкции влияют на курс национальной валюты",
        date: "21 апреля 2023",
        snippet: "Аналитики прогнозируют дальнейшее давление на рубль в связи с новым пакетом экономических санкций.",
        imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80"
      }
    ];

    const newsContainer = document.getElementById('news-container');
    newsContainer.innerHTML = '';

    mockNews.forEach(news => {
      const newsCard = document.createElement('div');
      newsCard.className = 'news-card';
      newsCard.innerHTML = `
        <img src="${news.imageUrl}" class="news-image" alt="${news.title}">
        <div class="news-content">
          <div class="news-title">${news.title}</div>
          <div class="news-date">${news.date}</div>
          <div class="news-snippet">${news.snippet}</div>
          <a href="#" class="news-link">Читать далее</a>
        </div>
      `;
      newsContainer.appendChild(newsCard);
    });
  }

  // Функция для загрузки погоды
  function loadWeather() {
    // Имитация погодных данных (в реальном проекте здесь был бы API запрос)
    const weatherIcons = ['fa-sun', 'fa-cloud-sun', 'fa-cloud', 'fa-cloud-rain', 'fa-snowflake'];
    const weatherDescriptions = ['Солнечно', 'Переменная облачность', 'Облачно', 'Дождь', 'Снег'];
    
    const randomIndex = Math.floor(Math.random() * weatherIcons.length);
    const temperature = Math.floor(Math.random() * 30) - 5; // от -5 до 25
    
    const weatherElement = document.getElementById('weather-info');
    weatherElement.innerHTML = `
      <i class="fas ${weatherIcons[randomIndex]}"></i>
      <span id="weather-temp">${temperature}°C</span>
      <span id="weather-desc">${weatherDescriptions[randomIndex]}</span>
    `;
  }

  // Функция для обновления данных о валютных парах
  function updateCurrencyPairs() {
    if (!currentRates.USD || !currentRates.EUR || !currentRates.CNY || !currentRates.KZT) return;
    
    // EUR/USD
    const eurUsdRate = currentRates.EUR / currentRates.USD;
    const eurUsdChange = (Math.random() * 2 - 1).toFixed(2); // случайное изменение от -1% до +1%
    
    // USD/CNY
    const usdCnyRate = currentRates.USD / currentRates.CNY;
    const usdCnyChange = (Math.random() * 2 - 1).toFixed(2);
    
    // EUR/CNY
    const eurCnyRate = currentRates.EUR / currentRates.CNY;
    const eurCnyChange = (Math.random() * 2 - 1).toFixed(2);
    
    // USD/KZT
    const usdKztRate = currentRates.USD / currentRates.KZT;
    const usdKztChange = (Math.random() * 2 - 1).toFixed(2);
    
    // Обновление DOM
    document.getElementById('pair-eurusd').textContent = eurUsdRate.toFixed(4);
    document.getElementById('pair-usdcny').textContent = usdCnyRate.toFixed(4);
    document.getElementById('pair-eurcny').textContent = eurCnyRate.toFixed(4);
    document.getElementById('pair-usdkzt').textContent = usdKztRate.toFixed(4);
    
    // Обновление изменений
    updatePairChange('pair-eurusd-change', eurUsdChange);
    updatePairChange('pair-usdcny-change', usdCnyChange);
    updatePairChange('pair-eurcny-change', eurCnyChange);
    updatePairChange('pair-usdkzt-change', usdKztChange);
  }
  
  function updatePairChange(elementId, change) {
    const element = document.getElementById(elementId);
    const changeNum = parseFloat(change);
    
    if (changeNum > 0) {
      element.innerHTML = `+${change}% <i class="fas fa-arrow-up"></i>`;
      element.className = 'pair-change up';
    } else if (changeNum < 0) {
      element.innerHTML = `${change}% <i class="fas fa-arrow-down"></i>`;
      element.className = 'pair-change down';
    } else {
      element.innerHTML = `${change}% <i class="fas fa-arrow-right"></i>`;
      element.className = 'pair-change';
    }
  }

  // Система уведомлений о курсах валют
  const alerts = [];
  
  // Функция для добавления уведомления
  document.getElementById('set-alert-btn').addEventListener('click', () => {
    const currency = document.getElementById('alert-currency').value;
    const threshold = parseFloat(document.getElementById('alert-threshold').value);
    const condition = document.getElementById('alert-condition').value;
    
    if (isNaN(threshold) || threshold <= 0) {
      alert('Пожалуйста, введите корректное пороговое значение');
      return;
    }
    
    // Добавляем новое уведомление
    const alertId = Date.now(); // уникальный идентификатор
    alerts.push({
      id: alertId,
      currency,
      threshold,
      condition
    });
    
    // Обновляем список уведомлений
    updateAlertsList();
    
    // Очищаем поле ввода
    document.getElementById('alert-threshold').value = '';
  });
  
  // Функция для обновления списка уведомлений
  function updateAlertsList() {
    const alertsContainer = document.getElementById('active-alerts');
    
    if (alerts.length === 0) {
      alertsContainer.innerHTML = '<p class="no-alerts">У вас нет активных уведомлений</p>';
      return;
    }
    
    alertsContainer.innerHTML = '';
    
    alerts.forEach(alert => {
      const alertItem = document.createElement('div');
      alertItem.className = 'alert-item';
      alertItem.innerHTML = `
        <div class="alert-info">
          <span class="alert-currency">${alert.currency}</span>
          <span class="alert-condition">${alert.condition === 'above' ? 'выше' : 'ниже'}</span>
          <span class="alert-value">${alert.threshold.toFixed(2)}</span>
        </div>
        <button class="delete-alert" data-id="${alert.id}"><i class="fas fa-times"></i></button>
      `;
      alertsContainer.appendChild(alertItem);
    });
    
    // Добавляем обработчики для кнопок удаления
    document.querySelectorAll('.delete-alert').forEach(button => {
      button.addEventListener('click', (e) => {
        const alertId = parseInt(e.currentTarget.dataset.id);
        // Удаляем уведомление из массива
        const index = alerts.findIndex(alert => alert.id === alertId);
        if (index !== -1) {
          alerts.splice(index, 1);
          updateAlertsList();
        }
      });
    });
  }
  
  // Функция для проверки уведомлений
  function checkAlerts() {
    if (alerts.length === 0 || Object.keys(currentRates).length === 0) return;
    
    alerts.forEach(alert => {
      const currentRate = currentRates[alert.currency];
      if (!currentRate) return;
      
      let triggered = false;
      
      if (alert.condition === 'above' && currentRate > alert.threshold) {
        triggered = true;
      } else if (alert.condition === 'below' && currentRate < alert.threshold) {
        triggered = true;
      }
      
      if (triggered) {
        // Показываем уведомление (в реальном приложении можно использовать push-уведомления)
        alert(`Уведомление: ${alert.currency} ${alert.condition === 'above' ? 'выше' : 'ниже'} ${alert.threshold.toFixed(2)}!`);
      }
    });
  }

  // Кнопка обновления курсов
  document.getElementById('refresh-btn').addEventListener('click', async () => {
    const button = document.getElementById('refresh-btn');
    button.textContent = 'Обновление...';
    button.disabled = true;

    const success = await fetchExchangeRates();

    button.disabled = false;
    button.textContent = success ? 'Обновить курсы' : 'Ошибка! Попробуйте снова';

    if (!success) {
      setTimeout(() => {
        button.textContent = 'Обновить курсы';
      }, 3000);
    } else {
      // Обновляем связанные данные
      updateCurrencyPairs();
      checkAlerts();
      displayRandomQuote(); // Обновляем цитату при обновлении курсов
    }
  });

  // Инициализация функциональности сохранения избранных валют
  function initFavorites() {
    // В реальном приложении здесь можно было бы реализовать сохранение избранных валют
    // и более сложную функциональность с LocalStorage
  }

  // Инициализация и отрисовка графика
  let currencyChart;

  function initChart() {
    const ctx = document.getElementById('currency-chart').getContext('2d');

    // Создание пустого графика
    currencyChart = new Chart(ctx, {
      type: 'line',
      data: {
          labels: [],
          datasets: [{
              label: 'Курс валюты',
              data: [],
              borderColor: 'rgb(74, 144, 226)',
              backgroundColor: 'rgba(74, 144, 226, 0.1)',
              borderWidth: 2,
              fill: true,
              tension: 0.2
          }]
      },
      options: {
          responsive: true,
          maintainAspectRatio: false,
          scales: {
              y: {
                  beginAtZero: false
              }
          },
          plugins: {
              tooltip: {
                  mode: 'index',
                  intersect: false
              },
              legend: {
                  position: 'top',
              }
          }
      }
    });

    // Обновить график с начальными данными
    updateChart('USD', 'month');

    // Добавить слушатели событий на выбор валюты и периода
    document.getElementById('chart-currency').addEventListener('change', (e) => {
        updateChart(e.target.value, document.getElementById('chart-period').value);
    });

    document.getElementById('chart-period').addEventListener('change', (e) => {
        updateChart(document.getElementById('chart-currency').value, e.target.value);
    });
  }

  // Обновление данных графика
  function updateChart(currency, period) {
    if (!currencyChart || !historicalRates[currency]) return;

    let dateLabels = historicalRates.dates;
    let rateData = historicalRates[currency];

    // Выбрать данные в зависимости от периода
    let dataLength;
    switch(period) {
      case 'week':
        dataLength = 7;
        break;
      case 'month':
        dataLength = 30;
        break;
      case 'quarter':
        dataLength = 90;
        break;
      default:
        dataLength = 30;
    }

    // Обрезать массивы до нужной длины
    const slicedLabels = dateLabels.slice(-dataLength);
    const slicedData = rateData.slice(-dataLength);

    // Отформатировать даты для отображения
    const formattedLabels = slicedLabels.map(dateStr => {
      const dateParts = dateStr.split('-');
      return `${dateParts[2]}.${dateParts[1]}`;
    });

    // Обновить данные графика
    currencyChart.data.labels = formattedLabels;
    currencyChart.data.datasets[0].data = slicedData;
    currencyChart.data.datasets[0].label = `Курс ${currency} к ${baseCurrency}`;
    currencyChart.update();
  }


  // Инициализация при загрузке страницы
  fetchExchangeRates();
  initChart();
  loadFinancialNews();
  loadWeather();
  updateAlertsList();
  
  // Обновляем погоду каждый час
  setInterval(loadWeather, 3600000);
  
  // Обновляем цитату при перезагрузке страницы
  window.addEventListener('beforeunload', () => {
    localStorage.setItem('lastQuoteRefresh', new Date().toISOString());
  });
});