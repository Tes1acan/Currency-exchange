
document.addEventListener('DOMContentLoaded', () => {
  // Переменные для хранения данных о курсах валют
  let currentRates = {};
  let historicalRates = {};
  let baseCurrency = 'RUB';

  // Переключение темы
  const toggleSwitch = document.querySelector('.theme-switch input[type="checkbox"]');
  
  function switchTheme(e) {
    if (e.target.checked) {
      document.documentElement.setAttribute('data-theme', 'dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.setAttribute('data-theme', 'light');
      localStorage.setItem('theme', 'light');
    }
  }
  
  toggleSwitch.addEventListener('change', switchTheme, false);
  
  // Проверка сохраненной темы
  const currentTheme = localStorage.getItem('theme') || 'light';
  if (currentTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
    toggleSwitch.checked = true;
  }
  
  // Обновление даты и времени
  function updateDateTime() {
    const now = new Date();
    const dateOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    const timeOptions = { hour: '2-digit', minute: '2-digit', second: '2-digit' };
    
    document.querySelector('.date').textContent = now.toLocaleDateString('ru-RU', dateOptions);
    document.querySelector('.time').textContent = now.toLocaleTimeString('ru-RU', timeOptions);
    
    document.getElementById('last-update').textContent = now.toLocaleTimeString('ru-RU', timeOptions);
  }
  
  // Обновление каждую секунду
  setInterval(updateDateTime, 1000);
  updateDateTime();
  
  // Функция для получения курсов валют
  async function fetchExchangeRates() {
    try {
      // В реальном проекте здесь был бы запрос к API
      // Для демонстрации используем фиктивные данные
      
      // Симуляция задержки сети
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Генерация случайных курсов валют для демонстрации
      const usdRate = 90 + Math.random() * 5;
      
      currentRates = {
        USD: usdRate,
        EUR: usdRate * (1 + (Math.random() * 0.2 - 0.1)),
        CNY: usdRate / (6.5 + Math.random()),
        KZT: usdRate / (0.0021 + Math.random() * 0.0005),
      };
      
      // Обновление исторических данных
      if (!historicalRates.USD) {
        historicalRates = generateHistoricalRates(currentRates, 30);
      }
      
      updateRatesDisplay();
      updateExchangeStatus();
      generateForecasts();
      
      return true;
    } catch (error) {
      console.error('Ошибка при получении курсов валют:', error);
      return false;
    }
  }
  
  // Генерация исторических данных для демонстрации
  function generateHistoricalRates(baseRates, days) {
    const historical = {
      USD: [],
      EUR: [],
      CNY: [],
      KZT: [],
      dates: []
    };
    
    const today = new Date();
    
    for (let i = days; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(today.getDate() - i);
      historical.dates.push(date.toISOString().split('T')[0]);
      
      // Добавление случайных колебаний для курсов
      const dayVariation = Math.random() * 0.04 - 0.02; // ±2%
      
      historical.USD.push(baseRates.USD * (1 + dayVariation + (i / days) * 0.05));
      historical.EUR.push(baseRates.EUR * (1 + dayVariation - (i / days) * 0.03));
      historical.CNY.push(baseRates.CNY * (1 + dayVariation + (i / days) * 0.02));
      historical.KZT.push(baseRates.KZT * (1 + dayVariation - (i / days) * 0.04));
    }
    
    return historical;
  }
  
  // Обновление отображения курсов валют
  function updateRatesDisplay() {
    for (const [currency, rate] of Object.entries(currentRates)) {
      const element = document.getElementById(currency.toLowerCase());
      if (element) {
        // Форматирование числа с разделителем тысяч и двумя знаками после запятой
        const formattedRate = rate.toLocaleString('ru-RU', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        element.querySelector('.currency-value').textContent = formattedRate;
      }
    }
  }
  
  // Определение статуса курса (выгодно/невыгодно)
  function updateExchangeStatus() {
    // Расчет средних значений за последние 7 дней
    const lastWeekAverages = {};
    const currencies = ['USD', 'EUR', 'CNY', 'KZT'];
    
    currencies.forEach(currency => {
      const ratesArray = historicalRates[currency];
      const lastWeekRates = ratesArray.slice(-8, -1); // последние 7 дней без сегодня
      const average = lastWeekRates.reduce((sum, rate) => sum + rate, 0) / lastWeekRates.length;
      lastWeekAverages[currency] = average;
    });
    
    // Обновление статуса для каждой валюты
    currencies.forEach(currency => {
      const element = document.getElementById(currency.toLowerCase());
      if (!element) return;
      
      const currentRate = currentRates[currency];
      const avgRate = lastWeekAverages[currency];
      const statusElement = element.querySelector('.currency-status');
      
      // Процентное отклонение от среднего
      const deviation = ((currentRate - avgRate) / avgRate) * 100;
      
      // Определение статуса на основе отклонения
      let statusClass, statusText;
      
      if (deviation <= -2) {
        statusClass = 'status-excellent';
        statusText = 'Отлично';
      } else if (deviation >= 2) {
        statusClass = 'status-bad';
        statusText = 'Плохо';
      } else {
        statusClass = 'status-good';
        statusText = 'Хорошо';
      }
      
      statusElement.className = 'currency-status ' + statusClass;
      statusElement.textContent = statusText;
    });
  }
  
  // Генерация прогнозов на основе исторических данных
  function generateForecasts() {
    // Простая линейная регрессия для прогнозирования
    const getLinearTrend = (data, days) => {
      const n = data.length;
      let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
      
      for (let i = 0; i < n; i++) {
        sumX += i;
        sumY += data[i];
        sumXY += i * data[i];
        sumXX += i * i;
      }
      
      const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
      const intercept = (sumY - slope * sumX) / n;
      
      // Прогноз на следующие дни
      const forecast = [];
      for (let i = 1; i <= days; i++) {
        forecast.push(intercept + slope * (n + i - 1));
      }
      
      return forecast;
    };
    
    // Получаем прогнозы для каждой валюты
    const forecastDays = 30; // на месяц вперед
    const forecasts = {};
    
    ['USD', 'EUR', 'CNY', 'KZT'].forEach(currency => {
      forecasts[currency] = getLinearTrend(historicalRates[currency], forecastDays);
    });
    
    // Создаем массив дат для прогноза
    const forecastDates = [];
    const today = new Date();
    
    for (let i = 1; i <= forecastDays; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      forecastDates.push(date.toISOString().split('T')[0]);
    }
    
    // Сохраняем прогнозы
    const forecastData = {
      dates: forecastDates,
      rates: forecasts
    };
    
    // Отображаем прогноз на завтра по умолчанию
    displayForecast(forecastData, 'tomorrow');
    
    // Добавляем обработчики для вкладок прогноза
    document.querySelectorAll('.forecast-tab').forEach(tab => {
      tab.addEventListener('click', () => {
        document.querySelectorAll('.forecast-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        displayForecast(forecastData, tab.dataset.period);
      });
    });
  }
  
  // Отображение прогноза в зависимости от выбранного периода
  function displayForecast(forecastData, period) {
    const tableBody = document.getElementById('forecast-table-body');
    tableBody.innerHTML = '';
    
    let days;
    switch (period) {
      case 'tomorrow':
        days = 1;
        break;
      case 'week':
        days = 7;
        break;
      case 'month':
        days = 30;
        break;
      default:
        days = 1;
    }
    
    for (let i = 0; i < days; i++) {
      const row = document.createElement('tr');
      
      // Форматирование даты
      const dateParts = forecastData.dates[i].split('-');
      const formattedDate = `${dateParts[2]}.${dateParts[1]}.${dateParts[0]}`;
      
      // Добавление ячейки с датой
      const dateCell = document.createElement('td');
      dateCell.textContent = formattedDate;
      row.appendChild(dateCell);
      
      // Добавление ячеек с прогнозами для каждой валюты
      ['USD', 'EUR', 'CNY', 'KZT'].forEach(currency => {
        const cell = document.createElement('td');
        const rate = forecastData.rates[currency][i];
        cell.textContent = rate.toLocaleString('ru-RU', {
          minimumFractionDigits: 2,
          maximumFractionDigits: 2
        });
        row.appendChild(cell);
      });
      
      tableBody.appendChild(row);
    }
  }
  
  // Функционал калькулятора валют
  const amountInput = document.getElementById('amount');
  const resultInput = document.getElementById('result');
  const fromCurrencySelect = document.getElementById('from-currency');
  const toCurrencySelect = document.getElementById('to-currency');
  const calculateBtn = document.getElementById('calculate-btn');
  const exchangeRateSpan = document.getElementById('exchange-rate');
  const swapBtn = document.getElementById('swap-currencies');
  
  // Функция расчета обмена валют
  function calculateExchange() {
    const amount = parseFloat(amountInput.value);
    if (isNaN(amount) || amount <= 0) {
      alert('Пожалуйста, введите корректную сумму');
      return;
    }
    
    const fromCurrency = fromCurrencySelect.value;
    const toCurrency = toCurrencySelect.value;
    
    // Получение курсов для расчета
    let rate;
    
    if (fromCurrency === 'RUB' && toCurrency === 'RUB') {
      rate = 1;
    } else if (fromCurrency === 'RUB') {
      rate = 1 / currentRates[toCurrency];
    } else if (toCurrency === 'RUB') {
      rate = currentRates[fromCurrency];
    } else {
      // Конвертация через рубль
      rate = currentRates[fromCurrency] / currentRates[toCurrency];
    }
    
    // Комиссия (0.5%)
    const commission = 0.005;
    document.getElementById('commission').textContent = '0.5%';
    
    // Расчет и отображение результата
    const result = amount * rate * (1 - commission);
    resultInput.value = result.toLocaleString('ru-RU', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).replace(/\s/g, '');
    
    // Отображение курса обмена
    exchangeRateSpan.textContent = rate.toLocaleString('ru-RU', {
      minimumFractionDigits: 4,
      maximumFractionDigits: 4
    });
  }
  
  // Обмен валют местами
  function swapCurrencies() {
    const tempCurrency = fromCurrencySelect.value;
    fromCurrencySelect.value = toCurrencySelect.value;
    toCurrencySelect.value = tempCurrency;
    
    if (amountInput.value && resultInput.value) {
      const tempAmount = amountInput.value;
      amountInput.value = resultInput.value;
      resultInput.value = tempAmount;
    }
  }
  
  // Обработчики событий
  calculateBtn.addEventListener('click', calculateExchange);
  swapBtn.addEventListener('click', swapCurrencies);
  
  // Кнопка обновления курсов
  document.getElementById('refresh-btn').addEventListener('click', async () => {
    const button = document.getElementById('refresh-btn');
    button.textContent = 'Обновление...';
    button.disabled = true;
    
    const success = await fetchExchangeRates();
    
    button.disabled = false;
    button.textContent = success ? 'Обновить курсы' : 'Ошибка! Попробуйте снова';
    
    if (!success) {
      setTimeout(() => {
        button.textContent = 'Обновить курсы';
      }, 3000);
    }
  });
  
  // Инициализация при загрузке страницы
  fetchExchangeRates();
});
